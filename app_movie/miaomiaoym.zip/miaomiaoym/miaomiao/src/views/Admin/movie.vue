<template>
    <div>
        电影
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>